﻿using Structor.Infrastructure.Entities;

namespace Structor.Features.Feature.Entities.Domains;

public class Domain : IEntity
{

}
