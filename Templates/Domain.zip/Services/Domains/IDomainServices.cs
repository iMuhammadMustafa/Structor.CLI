﻿namespace Structor.Features.Feature.Services.Domains;

public interface IDomainServices
{
}