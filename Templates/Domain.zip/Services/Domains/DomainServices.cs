﻿using Structor.Features.Feature.Repositories.Domains;

namespace Structor.Features.Feature.Services.Domains;

public class DomainServices : IDomainServices
{
    private readonly IDomainRepository _domainRepository;
    private readonly ILogger<DomainServices> _logger;


    public DomainServices(IDomainRepository domainRepository, ILogger<DomainServices> logger)
    {
        _domainRepository = domainRepository;
        _logger = logger;
    }
}
