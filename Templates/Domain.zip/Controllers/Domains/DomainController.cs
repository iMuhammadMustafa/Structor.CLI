﻿using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Structor.Features.Feature.Services.Domains;
using Structor.Infrastructure.DTOs.REST;

namespace Structor.Features.Feature.Controllers.Domains;

[ApiController]
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/[controller]/[action]")]
public class DomainController : ControllerBase
{
    private readonly IDomainServices _domainServices;

    public DomainController(IDomainServices domainServices)
    {
        _domainServices = domainServices;
    }

}
