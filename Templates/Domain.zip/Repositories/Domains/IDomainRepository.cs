﻿using Structor.Features.Feature.Entities.Domains;
using Structor.Infrastructure.Repositories;

namespace Structor.Features.Feature.Repositories.Domains;

public interface IDomainRepository : IRepository<Domain>
{
}
