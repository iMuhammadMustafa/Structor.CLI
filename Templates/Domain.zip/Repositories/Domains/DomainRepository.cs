﻿using Infrastructure.DatabaseContext;
using Microsoft.EntityFrameworkCore;
using Structor.Features.Feature.Entities.Domains;
using Structor.Infrastructure.Repositories;

namespace Structor.Features.Feature.Domains.Repositories;

public class DomainRepository : Repository<Domain, CoreDbContext>, IDomainRepository
{
    private readonly ILogger<DomainRepository> _logger;

    public DomainRepository(CoreDbContext coreDbContext, ILogger<DomainRepository> logger) : base(coreDbContext, logger)
    {
        _logger = logger;
    }

}
