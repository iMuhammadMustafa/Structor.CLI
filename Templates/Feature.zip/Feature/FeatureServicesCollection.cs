﻿using Infrastructure.DatabaseContext;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;


namespace Structor.Features.Feature;
public static class FeatureServicesCollection
{

    public static IServiceCollection AddFeatureServices(this IServiceCollection services, IConfiguration _configuration)
    {


        return services;
    }
}
