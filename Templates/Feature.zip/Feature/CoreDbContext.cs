﻿using Microsoft.EntityFrameworkCore;


namespace Infrastructure.DatabaseContext;
public partial class CoreDbContext : DbContext
{

}
